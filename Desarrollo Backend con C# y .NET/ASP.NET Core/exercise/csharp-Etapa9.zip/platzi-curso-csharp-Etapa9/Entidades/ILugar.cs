namespace CoreEscuela.Entidades
{
    public interface ILugar
    {
       string Dirección { get; set; }

       void LimpiarLugar();

    }
}