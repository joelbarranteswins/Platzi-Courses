using System;

namespace CoreEscuela.Entidades
{
    public class Asignatura:ObjetoEscuelaBase
    {

    }
}