
public enum LlaveDiccionario
{
    Escuela ,
    Curso,
    Alumno,
    Asignatura,
    Evaluación
}
