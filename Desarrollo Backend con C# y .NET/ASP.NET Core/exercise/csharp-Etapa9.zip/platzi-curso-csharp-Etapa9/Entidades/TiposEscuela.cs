namespace CoreEscuela.Entidades
{
    public enum TiposEscuela
    {
        Primaria, 
        Secundaria, 
        PreEscolar
    }
}