namespace CoreEscuela.Entidades
{
    public enum TiposJornada
    {
        Mañana, Tarde, Noche
    }
}