# {{ cookiecutter.project_title }}

By {{ cookiecutter.project_author_name }}

{{ cookiecutter.project_description }}

## License
