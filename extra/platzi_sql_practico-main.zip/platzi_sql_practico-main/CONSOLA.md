# Consola

```bash
psql -p 5433 platzi_sql_practico
```
